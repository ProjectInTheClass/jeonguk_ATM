//
//  Bank.swift
//  전국ATM찾기
//
//  Created by 홍재우, 이지호, 윤진 on 12/02/2019.
//  Copyright © 2019 CAUADC. All rights reserved.



import Foundation
import MapKit
import Contacts

class Bank: Decodable {
    
    var bank: String
    var name: String
    var add: String
    var lat: String
    var long: String
    var num: String?
    
    func mapItem() -> MKMapItem {
        let placemark = MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: Double(lat) ?? 0.0, longitude: Double(long) ?? 0.0))
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = bank
        return mapItem
    }
}
